    const cors = require("cors");

    const corsMiddleware = () => cors(); 

    module.exports = corsMiddleware;
